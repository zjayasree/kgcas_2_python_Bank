from flask import*
app=Flask(__name__)

@app.route("/login")
def login():
	return render_template("loginpage.html")
	


@app.route("/registration")
def registration():
	return render_template("registration.html")
	


if __name__=='__main__':
	app.run()

